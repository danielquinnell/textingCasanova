<?  if ($conn)
	{
		unset($conn);
	}
?>
	</div>	<!-- content div -->
</div>	<!-- maincolumn div -->
</body>
</html>